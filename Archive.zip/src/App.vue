<template>
  <Messenger />
</template>

<script>
import Messenger from './components/Messenger.vue'

export default {
  name: 'App',
  components: {
    Messenger
  }
}
</script>

