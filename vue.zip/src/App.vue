<template>
  <Messenger />
</template>

<script>
import Messenger from './components/Messenger.vue'

export default {
  name: 'App',
  components: {
    Messenger
  }
}
</script>

<style>
body {
  background-color: #bbc9e0;
  padding: 0;
}
</style>


