package ot

var Slice = slice
var InputLengthFunc = inputLengthFunc
var OutputLengthFunc = outputLengthFunc

type Joinable joinable
type Swappable swappable
